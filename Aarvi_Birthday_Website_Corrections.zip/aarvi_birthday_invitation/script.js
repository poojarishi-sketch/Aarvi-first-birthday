const intro = document.getElementById('intro');
const main = document.getElementById('mainContent');
document.getElementById('openInvite').addEventListener('click', () => {
  intro.classList.add('opening');
  setTimeout(() => {
    intro.classList.add('done');
    main.classList.remove('is-hidden');
    document.body.style.overflow = 'auto';
    setTimeout(() => intro.remove(), 1000);
    revealNow();
  }, 850);
});
document.body.style.overflow = 'hidden';

function revealNow(){
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if(entry.isIntersecting){ entry.target.classList.add('visible'); observer.unobserve(entry.target); }
    });
  }, {threshold: .12});
  document.querySelectorAll('.reveal').forEach(el => observer.observe(el));
}
revealNow();

// Event time is local to Mathura, India (IST).
const eventDate = new Date('2026-12-01T18:00:00+05:30').getTime();
function tick(){
  let diff = Math.max(0, eventDate - Date.now());
  const d = Math.floor(diff / 86400000); diff %= 86400000;
  const h = Math.floor(diff / 3600000); diff %= 3600000;
  const m = Math.floor(diff / 60000); diff %= 60000;
  const s = Math.floor(diff / 1000);
  document.getElementById('days').textContent = String(d).padStart(2,'0');
  document.getElementById('hours').textContent = String(h).padStart(2,'0');
  document.getElementById('minutes').textContent = String(m).padStart(2,'0');
  document.getElementById('seconds').textContent = String(s).padStart(2,'0');
}
tick(); setInterval(tick,1000);

// RSVP opens the guest's WhatsApp share sheet with a ready message.
const yesText = encodeURIComponent("Hello! We would love to join Aarvi's 1st birthday celebration on 1 December 2026 at HOTEL HEERA CRYSTAL INN, Mathura. 🎀");
const noText = encodeURIComponent("Hello! Thank you for inviting us to Aarvi's 1st birthday. Unfortunately, we won't be able to attend. Sending lots of love! 💗");
document.getElementById('yesRsvp').href = 'https://wa.me/?text=' + yesText;
document.getElementById('noRsvp').href = 'https://wa.me/?text=' + noText;

// Gentle original chime motif using Web Audio; no external music file required.
let audioCtx, musicTimer, noteIndex = 0;
const notes = [523.25,659.25,783.99,659.25,587.33,698.46,880,698.46];
function playNote(){
  if(!audioCtx) return;
  const osc = audioCtx.createOscillator(), gain = audioCtx.createGain();
  osc.type = 'sine'; osc.frequency.value = notes[noteIndex++ % notes.length];
  gain.gain.setValueAtTime(.0001,audioCtx.currentTime);
  gain.gain.exponentialRampToValueAtTime(.035,audioCtx.currentTime+.08);
  gain.gain.exponentialRampToValueAtTime(.0001,audioCtx.currentTime+.8);
  osc.connect(gain); gain.connect(audioCtx.destination);
  osc.start(); osc.stop(audioCtx.currentTime+.85);
}
const musicBtn = document.getElementById('musicToggle');
musicBtn.addEventListener('click', async () => {
  const label = document.getElementById('musicLabel');
  if(!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  if(audioCtx.state === 'suspended') await audioCtx.resume();
  if(musicTimer){
    clearInterval(musicTimer); musicTimer = null;
    musicBtn.classList.remove('playing'); label.textContent = 'MUSIC OFF';
  } else {
    playNote(); musicTimer = setInterval(playNote, 900);
    musicBtn.classList.add('playing'); label.textContent = 'MUSIC ON';
  }
});
